module.exports = client => {
  console.log(`Bağlantın Koptu! ${new Date()}`);
};
